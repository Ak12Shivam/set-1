const express = require('express');
const Poll = require('../models/Poll');
const auth = require('../middleware/Auth');
const router = express.Router();

router.post('/', auth, async (req, res) => {
    const { title, options } = req.body;
    if (!title || !options || options.length < 2 || options.length > 5)
      return res.status(400).json({ msg: 'Poll must have a title and 2-5 options' });
  
    const poll = new Poll({
      title,
      options: options.map(opt => ({ option: opt })),
      createdBy: req.user.id,
    });
  
    try {
      await poll.save();
      res.json(poll);
    } catch (err) {
      res.status(500).send('Server error');
    }
  });

  router.get('/', async (req, res) => {
    try {
      const polls = await Poll.find().select('title options');
      res.json(polls);
    } catch (err) {
      res.status(500).send('Server error');
    }
  });

  router.get('/:id', async (req, res) => {
    try {
      const poll = await Poll.findById(req.params.id);
      if (!poll) return res.status(404).json({ msg: 'Poll not found' });
      res.json(poll);
    } catch (err) {
      res.status(500).send('Server error');
    }
  });

  router.post('/:id/vote', auth, async (req, res) => {
    const { optionIndex } = req.body;
    try {
      const poll = await Poll.findById(req.params.id);
      if (!poll) return res.status(404).json({ msg: 'Poll not found' });
      if (poll.voters.includes(req.user.id))
        return res.status(400).json({ msg: 'User has already voted' });
  
      if (optionIndex < 0 || optionIndex >= poll.options.length)
        return res.status(400).json({ msg: 'Invalid option' });
  
      poll.options[optionIndex].votes += 1;
      poll.voters.push(req.user.id);
      await poll.save();
  
      res.json(poll);
    } catch (err) {
      res.status(500).send('Server error');
    }
  });
  
  module.exports = router;
  