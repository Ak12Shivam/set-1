const express = require("express");
const router = express.Router();
const auth = require("../middleware/auth");
const {
  createPoll,
  getAllPolls,
  getPollById,
  votePoll,
} = require("../controllers/pollController");

router.post("/", auth, createPoll);
router.get("/", getAllPolls);
router.get("/:id", getPollById);
router.post("/:id/vote", auth, votePoll);

module.exports = router;
