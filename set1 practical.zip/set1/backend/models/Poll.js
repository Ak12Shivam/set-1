const mongoose = require("mongoose");

const pollSchema = new mongoose.Schema({
  title: String,
  options: [
    {
      text: String,
      votes: { type: Number, default: 0 },
    },
  ],
  votes: [{ userId: mongoose.Schema.Types.ObjectId }],
  createdBy: mongoose.Schema.Types.ObjectId,
});

module.exports = mongoose.model("Poll", pollSchema);
