const Poll = require("../models/Poll");

exports.createPoll = async (req, res) => {
  const { title, options } = req.body;
  if (options.length < 2 || options.length > 5)
    return res.status(400).send("2-5 options only");
  const formattedOptions = options.map((text) => ({ text }));
  const poll = new Poll({
    title,
    options: formattedOptions,
    createdBy: req.userId,
  });
  await poll.save();
  res.json(poll);
};

exports.getAllPolls = async (req, res) => {
  const polls = await Poll.find({}, "title");
  res.json(polls);
};

exports.getPollById = async (req, res) => {
  const poll = await Poll.findById(req.params.id);
  res.json(poll);
};

exports.votePoll = async (req, res) => {
  const poll = await Poll.findById(req.params.id);
  if (!poll) return res.status(404).send("Poll not found");

  if (poll.votes.some((v) => v.userId.toString() === req.userId)) {
    return res.status(400).send("Already voted");
  }

  const optionIndex = req.body.option;
  if (optionIndex < 0 || optionIndex >= poll.options.length) {
    return res.status(400).send("Invalid option");
  }

  poll.options[optionIndex].votes += 1;
  poll.votes.push({ userId: req.userId });
  await poll.save();
  res.send("Voted");
};
