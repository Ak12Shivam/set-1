// frontend/src/App.js
import React, { useEffect, useState } from "react";
import { BrowserRouter as Router, Routes, Route, Link, useNavigate } from "react-router-dom";
import axios from "axios";

const API = "http://localhost:5000/api";

function Register() {
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const navigate = useNavigate();

  const handleRegister = async () => {
    await axios.post(`${API}/auth/register`, { username, password });
    alert("Registered. Please login.");
    navigate("/login");
  };

  return (
    <div>
      <h2>Register</h2>
      <input placeholder="Username" onChange={(e) => setUsername(e.target.value)} /><br />
      <input type="password" placeholder="Password" onChange={(e) => setPassword(e.target.value)} /><br />
      <button onClick={handleRegister}>Register</button>
    </div>
  );
}

function Login({ setToken }) {
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const navigate = useNavigate();

  const handleLogin = async () => {
    const res = await axios.post(`${API}/auth/login`, { username, password });
    setToken(res.data.token);
    navigate("/polls");
  };

  return (
    <div>
      <h2>Login</h2>
      <input placeholder="Username" onChange={(e) => setUsername(e.target.value)} /><br />
      <input type="password" placeholder="Password" onChange={(e) => setPassword(e.target.value)} /><br />
      <button onClick={handleLogin}>Login</button>
    </div>
  );
}

function CreatePoll({ token }) {
  const [title, setTitle] = useState("");
  const [options, setOptions] = useState(["", ""]);

  const handleCreate = async () => {
    await axios.post(`${API}/polls`, { title, options }, {
      headers: { Authorization: token },
    });
    alert("Poll created");
  };

  return (
    <div>
      <h2>Create Poll</h2>
      <input placeholder="Poll Title" onChange={(e) => setTitle(e.target.value)} /><br />
      {options.map((opt, idx) => (
        <input
          key={idx}
          placeholder={`Option ${idx + 1}`}
          value={opt}
          onChange={(e) => {
            const newOpts = [...options];
            newOpts[idx] = e.target.value;
            setOptions(newOpts);
          }}
        />
      ))}<br />
      {options.length < 5 && (
        <button onClick={() => setOptions([...options, ""])}>Add Option</button>
      )}<br />
      <button onClick={handleCreate}>Create</button>
    </div>
  );
}

function Polls({ token }) {
  const [polls, setPolls] = useState([]);
  const [selectedPoll, setSelectedPoll] = useState(null);

  useEffect(() => {
    axios.get(`${API}/polls`).then((res) => setPolls(res.data));
  }, []);

  const fetchPoll = async (id) => {
    const res = await axios.get(`${API}/polls/${id}`);
    setSelectedPoll(res.data);
  };

  const vote = async (optionIndex) => {
    try {
      await axios.post(`${API}/polls/${selectedPoll._id}/vote`, { option: optionIndex }, {
        headers: { Authorization: token },
      });
      fetchPoll(selectedPoll._id);
    } catch (err) {
      alert(err.response.data);
    }
  };

  return (
    <div>
      <h2>All Polls</h2>
      {polls.map((p) => (
        <div key={p._id}>
          <button onClick={() => fetchPoll(p._id)}>{p.title}</button>
        </div>
      ))}

      {selectedPoll && (
        <div>
          <h3>{selectedPoll.title}</h3>
          {selectedPoll.options.map((opt, idx) => (
            <div key={idx}>
              <button onClick={() => vote(idx)}>{opt.text}</button> - Votes: {opt.votes}
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

export default function App() {
  const [token, setToken] = useState("");

  return (
    <Router>
      <nav>
        <Link to="/register">Register</Link> | <Link to="/login">Login</Link> | <Link to="/polls">Polls</Link> | <Link to="/create">Create Poll</Link>
      </nav>
      <Routes>
        <Route path="/register" element={<Register />} />
        <Route path="/login" element={<Login setToken={setToken} />} />
        <Route path="/polls" element={<Polls token={token} />} />
        <Route path="/create" element={<CreatePoll token={token} />} />
      </Routes>
    </Router>
  );
}

